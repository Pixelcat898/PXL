Extensions are a feature not fully worked out, 
I don't really understand but from what im getting at they are ran after the main code, 
They also need to be a .lua file.

Run execute.bat to Run your PXL file.
I wont go into how to program in "Pixel Programming" (PXL)

Coded with Visual Studio 2013 (Windows 8.1)