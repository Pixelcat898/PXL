local File = io.open("pxlcode.pxl", "r")
local Variables = {}
local Extensions = {}
local ExtensionText = {}

local CanSearchForVariables = true
local InCompareStatement = false

--segment"var"

for i = 1, 100 do
    if CanSearchForVariables == true then
        local VariableData = File:read("*l")

        if string.match(VariableData, "code") then
            CanSearchForVariables = false
        else
            if string.match(VariableData, "segment", 0) or string.match(VariableData, "}", 0)  then
            else
                table.insert(Variables, string.sub(VariableData, 5, 7))
                table.insert(Variables, string.sub(VariableData, 9, 19))
            end
        end
    else
        break
    end
end

--segment"code"

for i = 1, 10000 do
    local FileData = File:read("*l")

    if FileData ~= nil then
        --PRNT

        if FileData:find("prnt") then
            local VariableMode = false

            if string.match(FileData, "var:", 10) then
                VariableMode = true

                local VariableName = string.sub(FileData, 14, 16)
                local Number = 0

                for j = 1, #Variables do
                    if Variables[j] == VariableName then
                        Number = j

                        break
                    end
                end

                print(Variables[Number + 1])
            end

            local PrintString = string.sub(FileData, 10, string.len(FileData) - 1)

            if VariableMode == false then
                print(PrintString)
            end
        end

        --ADDV

        if FileData:find("addv") then
            if string.match(FileData, "var:", 10) then
                local VariableName = string.sub(FileData, 14, 16)
                local Number = 0

                for j = 1, #Variables do
                    if Variables[j] == VariableName then
                        Number = j

                        break
                    end
                end

                Variables[Number + 1] = Variables[Number + 1] + 1
            end
        end
    end

    -- SUBV

    if FileData:find("subv") then
        if string.match(FileData, "var:", 10) then
            local VariableName = string.sub(FileData, 14, 16)
            local Number = 0

            for j = 1, #Variables do
                if Variables[j] == VariableName then
                    Number = j

                    break
                end
            end

            Variables[Number + 1] = Variables[Number + 1] - 1
        end
    end

    -- End of executing code

    if string.match(FileData, "segment", 1) then
        break
    end
end

--segment"extra" (Libraries)

for i = 1, 10 do
    local ExtensionData = File:read("*l")

    if ExtensionData ~= nil then
        if string.match(ExtensionData, "incl", 1) then
            table.insert(Extensions, dofile(string.sub(ExtensionData, 10, 10000)))
            table.insert(ExtensionText, string.sub(ExtensionData, 10, 10000))
        end
    else
        break
    end
end

print("")
print("Pixel-Programming (By Pixel) V 0.1.7 (21/12/2023)")

for i = 1, #Extensions do
    print(ExtensionText[i] .." - Loading")
    print("")
    print(ExtensionText[i] ..":")

    Extensions[i].MainCode(File)

    print("")
end