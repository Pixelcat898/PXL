local module = {}

function module.MainCode(File)
    for i = 1, 10 do
        print("Yay")
    end
end

return module